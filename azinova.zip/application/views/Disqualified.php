<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!-- Begin page content -->
<main class="flex-shrink-0 mt-5">
	<div class="container mt-2">
		<h2>Disqualified</h2>
		<h4 class="text-danger">Sorry your test is disqualified due to reload page.</h4>
	</div>
</main>