<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<footer class="footer mt-auto py-3 bg-light">
	<div class="container">
		<span class="text-muted">PHP Machine Test Create for Azinova by Samnad</span>
	</div>
</footer>

</body>

</html>