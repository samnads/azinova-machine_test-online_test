<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!-- Begin page content -->
<main class="flex-shrink-0 mt-5">
	<div class="container mt-2">
		<h2>Registration Successfull !</h2>
		<hr>
		<h3>Hi,<?php echo $name; ?> you have successfully registered in our site !</h3>
		<h3>Click <a href="./login">here</a> to login !</h3>
</main>